<?php
$telegram_id = "6983301151";
$id_bot = "7340736935:AAFKwSXYTyf2SIvtnmbi2DmVvzgYcv9egIw";
?>
